# RAWviewer v0.4.0

A powerful, cross-platform RAW image viewer built with PyQt6. View and navigate through your RAW photos with ease.

## ✨ Features

- **Cross-platform support**: Windows and macOS
- **Wide RAW format support**: Canon (CR2, CR3), Nikon (NEF), Sony (ARW), Adobe DNG, and many more
- **Smart NEF compatibility**: Automatic thumbnail fallback for problematic NEF files
- **Automatic orientation correction**: Reads EXIF orientation data and displays images correctly (portrait/landscape)
- **Intuitive navigation**: Keyboard shortcuts and mouse controls
- **Zoom functionality**: Fit-to-window and 100% zoom modes with smooth panning
- **File management**: Move images to discard folder or delete permanently
- **EXIF data display**: View camera settings and capture information
- **Session persistence**: Remembers your last opened folder and image

## 🔧 NEF File Compatibility

RAWviewer includes advanced compatibility features for Nikon NEF files:

- **Full RAW processing** for most NEF files
- **Automatic thumbnail fallback** for NEF files with LibRaw compatibility issues
- **Smart error handling** with informative status messages
- **High-quality thumbnails** extracted directly from NEF files when needed

> **Note**: Some newer NEF files may trigger the thumbnail fallback due to LibRaw 0.21.3 compatibility issues. This is a known limitation that provides excellent image quality through embedded thumbnails while maintaining full functionality.

## 🚀 Quick Start

### Windows
1. Download `RAWviewer.exe` from the latest release
2. Double-click to run - no installation required!

### macOS
1. Download `RAWviewer-v0.4.0-macOS.zip` from the latest release
2. Extract the ZIP file
3. Run `RAWviewer.app` or use the command-line version

## ⌨️ Keyboard Shortcuts

### Windows
- **Ctrl+O**: Open image file
- **Ctrl+Shift+O**: Open folder of images
- **Space**: Toggle between fit-to-window and 100% zoom
- **Left/Right arrows**: Navigate between images
- **Down arrow**: Move current image to Discard folder
- **Delete**: Delete current image (with confirmation)

### macOS
- **Cmd+O**: Open image file
- **Cmd+Shift+O**: Open folder of images
- **Space**: Toggle between fit-to-window and 100% zoom
- **Left/Right arrows**: Navigate between images
- **Down arrow**: Move current image to Discard folder
- **Delete**: Delete current image (with confirmation)

## 🖱️ Mouse Controls

- **Double-click**: Toggle zoom mode
- **Click and drag**: Pan image when zoomed in
- **Drag and drop**: Open images or folders

## 📁 Supported Formats

### RAW Formats
- **Canon**: CR2, CR3
- **Nikon**: NEF (with smart compatibility features)
- **Sony**: ARW, SRF
- **Adobe**: DNG
- **Olympus**: ORF
- **Panasonic**: RW2
- **Pentax**: PEF
- **Samsung**: SRW
- **Sigma**: X3F
- **Fujifilm**: RAF
- **Hasselblad**: 3FR, FFF
- **Phase One**: IIQ, CAP
- **Epson**: ERF
- **Mamiya**: MEF
- **Leaf**: MOS
- **Casio**: NRW
- **Leica**: RWL

### Standard Formats
- **JPEG**: JPG, JPEG
- **HEIF**: HEIF

## 🔧 Installation from Source

### Prerequisites
- Python 3.8 or higher
- Virtual environment (recommended)

### Setup
```bash
# Clone the repository
git clone https://github.com/yourusername/RAWviewer.git
cd RAWviewer

# Create virtual environment
python -m venv rawviewer_env

# Activate virtual environment
# Windows:
rawviewer_env\Scripts\activate
# macOS/Linux:
source rawviewer_env/bin/activate

# Install dependencies
pip install -r requirements.txt

# Run RAWviewer
python src/main.py
```

## 🏗️ Building

### Windows
```bash
# Activate virtual environment
rawviewer_env\Scripts\activate

# Build executable
python build.py
```

### macOS
```bash
# Activate virtual environment
source rawviewer_env/bin/activate

# Build app bundle
./build_macos.sh
```

## 🐛 Troubleshooting

### Windows
- **"Windows protected your PC"**: Click "More info" → "Run anyway"
- **Antivirus warnings**: Add RAWviewer to your antivirus exclusions
- **Performance issues**: Try running as administrator

### macOS
- **"App is damaged" error**: Go to System Preferences → Security & Privacy → Allow
- **Gatekeeper warnings**: Right-click the app → Open → Open anyway
- **Performance issues**: Grant Full Disk Access in Privacy settings

### NEF File Issues
- **"LibRaw compatibility issue" message**: This is normal for some NEF files - thumbnail fallback provides excellent quality
- **No thumbnail available**: The NEF file may be corrupted or use an unsupported compression method
- **Slow loading**: Large NEF files may take longer to process thumbnails

## 📋 System Requirements

### Minimum
- **OS**: Windows 10 or macOS 10.15
- **RAM**: 4GB
- **Storage**: 100MB free space

### Recommended
- **OS**: Windows 11 or macOS 12+
- **RAM**: 8GB or more
- **Storage**: 500MB free space for large RAW files

## 🔄 Version History

### v0.4.0 (Current)
- ✅ Full cross-platform support (Windows + macOS)
- ✅ Smart NEF compatibility with thumbnail fallback
- ✅ Enhanced zoom functionality with proper centering
- ✅ Improved error handling and user feedback
- ✅ Session state persistence
- ✅ Comprehensive keyboard shortcuts

### v0.2.0
- Initial Windows-only release
- Basic RAW file support
- Simple zoom and navigation

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📞 Support

If you encounter any issues:
1. Check the troubleshooting section above
2. Search existing GitHub issues
3. Create a new issue with detailed information about your problem

---

**Enjoy viewing your RAW photos with RAWviewer!** 📸
